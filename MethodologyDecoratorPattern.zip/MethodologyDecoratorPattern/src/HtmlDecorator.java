public abstract class HtmlDecorator extends HtmlBase{
    public abstract String getTag();



}
