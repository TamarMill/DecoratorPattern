public abstract class HtmlBase {
    String name;
    String id;
    String tag = "Unknown tag";

    public  String getTag(){
        return tag;
    }

}

